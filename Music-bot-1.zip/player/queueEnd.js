module.exports = (client, message, queue) => {
    message.channel.send(`${client.emotes.error} - Keluar dulu yaa, soalnya gak ada lagu lagi !`);
};