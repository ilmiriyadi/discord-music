module.exports = (client, message, query, tracks) => {
    message.channel.send(`${client.emotes.error} - Kamu tulis command yang salah, coba lagi !`);
};